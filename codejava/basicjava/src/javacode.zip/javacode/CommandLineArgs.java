package javacode;

public class CommandLineArgs {
	public static void main(String[] args) {
		String[] city= {"Chennai","Pune","Mumbai"};
		for(String element:city) {
			System.out.println(element);
		}
	}
}
